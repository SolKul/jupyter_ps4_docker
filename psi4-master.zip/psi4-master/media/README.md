[LAB 10-19-2016]

* Majority of logos detached from main Psi4 repo into https://github.com/psi4/psi4media .

[LAB 9-29-2016]

* See doc/sphinxman/source/psi4doc/themes/psi4doc/theme.conf
  for Psi4 colors and customary icon linking.

[LAB 2-18-2015]

* Text "SI" in "PSI4" changed to 82% size of "P" & "4"; 54 pt for banner
  files. This should avoid the "Public School 14" issue, while not looking
  so lopsided as genuine small-caps font.

[LAB 11-18-2014]

* Text "Ab Initio" changed to "Open-Source"

[LAB 4-20-2012]

* Text "PSI4" is Optima Regular at 66 pt in CMYK = [100, 95, 0, 0]

* Text "Ab Initio Quantum Chemistry" is Optima Bold at 16 pt
  in CMYK = [0, 0, 0, 100] with 100 (AI units) spacing stretch

* The difference between "vector" and other files in this directory is in
  the trimming of self-interference at the tips of the psi graphic. This
  process turns the psi into a raster object, so the color and 3D effects
  are no longer editable.

* All transparencies are set such that these can be placed over any color
  background.


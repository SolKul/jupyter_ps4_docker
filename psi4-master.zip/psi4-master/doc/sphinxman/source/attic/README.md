Here lie files that were once worthy documentation, but now their contents
or their code has become out-of-date. Also here are files whose content
only needs a once-over for validity but whose format needs conversion
from LaTeX, HTML, manpage, etc. to reStructuredText.


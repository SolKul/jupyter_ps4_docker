__version__ = '1.4rc1'
__version_long = '1.4rc1+2d37164'
__version_upcoming_annotated_v_tag = '1.4rc2'

def version_formatter(dummy):
    return '(inplace)'

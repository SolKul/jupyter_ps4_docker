#!/usr/bin/bash

rm *autogen*gbs ma*gbs apr*gbs jun*gbs heavy*gbs feb*gbs d-aug*gbs tmpB.txt tmpR.txt
rm cc*gbs aug*gbs

